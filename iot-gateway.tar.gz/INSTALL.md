# IoT Gateway - Installationsanleitung

## Inhaltsverzeichnis
1. [Systemvoraussetzungen](#1-systemvoraussetzungen)
2. [Grundinstallation](#2-grundinstallation)
3. [MySQL Einrichtung](#3-mysql-einrichtung)
4. [Anwendungsinstallation](#4-anwendungsinstallation)
5. [Konfiguration](#5-konfiguration)
6. [Dienste einrichten](#6-dienste-einrichten)
7. [Sicherheit](#7-sicherheit)
8. [Wartung & Backup](#8-wartung--backup)
9. [Fehlerbehebung](#9-fehlerbehebung)

## 1. Systemvoraussetzungen

### Hardware
- Mindestens 2 CPU-Kerne
- Mindestens 2 GB RAM
- Mindestens 20 GB Festplattenspeicher

### Software
- Ubuntu Server 24.04 LTS
- Python 3.12
- MySQL 8.0
- MQTT Broker (Mosquitto)
- Nginx
- Git

## 2. Grundinstallation

### System aktualisieren
```bash
# System auf den neuesten Stand bringen
sudo apt update
sudo apt upgrade -y

# Zeitzone einstellen (falls noch nicht geschehen)
sudo timedatectl set-timezone Europe/Berlin
```

### Benötigte Pakete installieren
```bash
# Grundlegende Pakete
sudo apt install -y python3 python3-venv python3-dev python3-pip \
                    mysql-server mosquitto mosquitto-clients \
                    git nginx supervisor \
                    build-essential libssl-dev libffi-dev
```

## 3. MySQL Einrichtung

### MySQL absichern
```bash
# MySQL secure installation durchführen
sudo mysql_secure_installation

# Folgende Fragen mit 'Y' beantworten:
# - Set up VALIDATE PASSWORD component? Y
# - Choose password validation level: 2 (Strong)
# - Change the password for root? Y (wenn noch nicht geschehen)
# - Remove anonymous users? Y
# - Disallow root login remotely? Y
# - Remove test database? Y
# - Reload privilege tables now? Y
```

### Datenbank und Benutzer erstellen
```bash
# MySQL als Root starten
sudo mysql

# Im MySQL-Terminal:
CREATE DATABASE iot_gateway CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'iot_user'@'localhost' IDENTIFIED BY 'IhrSicheresPasswort';
GRANT ALL PRIVILEGES ON iot_gateway.* TO 'iot_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

## 4. Anwendungsinstallation

### Anwendungsverzeichnis vorbereiten
```bash
# Als normaler Benutzer
cd /home/administrator

# Repository klonen
git clone https://github.com/IhrUsername/iot-gateway.git
cd iot-gateway

# Virtuelle Umgebung erstellen
python3 -m venv venv
source venv/bin/activate

# Pip aktualisieren und Abhängigkeiten installieren
pip install --upgrade pip
pip install -r requirements.txt
```

## 5. Konfiguration

### Umgebungsvariablen
```bash
# .env Datei erstellen
cat > .env << EOL
# Flask Konfiguration
FLASK_APP=run.py
FLASK_ENV=production
SECRET_KEY=$(python3 -c 'import secrets; print(secrets.token_hex(32))')

# Datenbank
DATABASE_URL=mysql://iot_user:IhrSicheresPasswort@localhost/iot_gateway

# MQTT Broker
MQTT_BROKER_URL=localhost
MQTT_BROKER_PORT=1883
MQTT_USERNAME=mqtt_user
MQTT_PASSWORD=IhrMQTTPasswort
MQTT_KEEPALIVE=60

# Logging
LOG_LEVEL=INFO
LOG_FILE=/var/log/iot-gateway/app.log
EOL
```

### Verzeichnisse und Berechtigungen
```bash
# Log-Verzeichnis erstellen
sudo mkdir -p /var/log/iot-gateway
sudo chown administrator:administrator /var/log/iot-gateway

# Anwendungsberechtigungen setzen
sudo chown -R administrator:administrator /home/administrator/iot-gateway
sudo chmod -R 755 /home/administrator/iot-gateway
```

## 6. Dienste einrichten

### Supervisor Konfiguration
```bash
# Supervisor Konfigurationsdatei erstellen
sudo tee /etc/supervisor/conf.d/iot-gateway.conf << EOL
[program:iot-gateway]
directory=/home/administrator/iot-gateway
command=/home/administrator/iot-gateway/venv/bin/gunicorn -w 4 -b 127.0.0.1:5000 run:app
user=administrator
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
stderr_logfile=/var/log/iot-gateway/supervisor.err.log
stdout_logfile=/var/log/iot-gateway/supervisor.out.log
environment=
    PYTHONPATH="/home/administrator/iot-gateway",
    PATH="/home/administrator/iot-gateway/venv/bin"
EOL

# Supervisor neuladen
sudo supervisorctl reread
sudo supervisorctl update
```

### Nginx als Reverse Proxy
```bash
# Nginx Konfiguration erstellen
sudo tee /etc/nginx/sites-available/iot-gateway << EOL
server {
    listen 80;
    server_name _;

    access_log /var/log/nginx/iot-gateway.access.log;
    error_log /var/log/nginx/iot-gateway.error.log;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_buffering off;
        proxy_redirect off;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    location /static {
        alias /home/administrator/iot-gateway/app/static;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
}
EOL

# Symlink erstellen und Nginx neustarten
sudo ln -s /etc/nginx/sites-available/iot-gateway /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx
```

## 7. Sicherheit

### Firewall einrichten
```bash
# UFW Regeln erstellen
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw allow 1883  # MQTT
sudo ufw enable
```

### SSL/TLS mit Let's Encrypt
```bash
# Certbot installieren
sudo apt install -y certbot python3-certbot-nginx

# Zertifikat beantragen (Domain anpassen)
sudo certbot --nginx -d ihre-domain.de
```

## 8. Wartung & Backup

### Automatische Backups einrichten
```bash
# Backup-Skript erstellen
sudo tee /usr/local/bin/backup-iot-gateway.sh << EOL
#!/bin/bash
BACKUP_DIR="/var/backups/iot-gateway"
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)
mkdir -p \$BACKUP_DIR

# Datenbank backup
mysqldump -u iot_user -p'IhrSicheresPasswort' iot_gateway > \$BACKUP_DIR/db_\$TIMESTAMP.sql

# Anwendungsbackup
tar -czf \$BACKUP_DIR/app_\$TIMESTAMP.tar.gz -C /home/administrator iot-gateway

# Alte Backups löschen (älter als 30 Tage)
find \$BACKUP_DIR -type f -mtime +30 -delete
EOL

# Skript ausführbar machen
sudo chmod +x /usr/local/bin/backup-iot-gateway.sh

# Cronjob einrichten (täglich um 3 Uhr)
(crontab -l 2>/dev/null; echo "0 3 * * * /usr/local/bin/backup-iot-gateway.sh") | crontab -
```

### Datenbank-Wartung
```bash
# MySQL Wartung (monatlich ausführen)
sudo mysqlcheck -u root -p --auto-repair --optimize iot_gateway
```

## 9. Fehlerbehebung

### Logs überprüfen
```bash
# Anwendungslogs
tail -f /var/log/iot-gateway/app.log

# Supervisor Logs
tail -f /var/log/iot-gateway/supervisor.*.log

# Nginx Logs
tail -f /var/log/nginx/iot-gateway.*.log
```

### Dienste neustarten
```bash
# Anwendung neustarten
sudo supervisorctl restart iot-gateway

# Nginx neustarten
sudo systemctl restart nginx

# MySQL neustarten
sudo systemctl restart mysql

# MQTT Broker neustarten
sudo systemctl restart mosquitto
```

### Häufige Probleme

#### Datenbank-Verbindungsfehler
```bash
# MySQL-Status prüfen
sudo systemctl status mysql

# Benutzerrechte prüfen
mysql -u root -p -e "SHOW GRANTS FOR 'iot_user'@'localhost';"
```

#### Berechtigungsprobleme
```bash
# Berechtigungen korrigieren
sudo chown -R administrator:administrator /home/administrator/iot-gateway
sudo chmod -R 755 /home/administrator/iot-gateway
sudo chown -R administrator:administrator /var/log/iot-gateway
```

#### Speicherprobleme
```bash
# Speicherauslastung prüfen
df -h
free -m

# Cache leeren
sudo sync; echo 3 | sudo tee /proc/sys/vm/drop_caches
```

---

Nach der Installation können Sie sich mit den Standard-Zugangsdaten anmelden:
- Benutzername: admin
- Passwort: admin123

**WICHTIG**: Ändern Sie das Admin-Passwort sofort nach der ersten Anmeldung!
